﻿using Microsoft.AspNetCore.Authentication;

namespace $safeprojectname$.Auth.Authentication
{
    public class CustomAuthenticationOptions : AuthenticationSchemeOptions
    {
        public const string DefaultScheme = "TokenAuthenticationScheme";
    }
}
