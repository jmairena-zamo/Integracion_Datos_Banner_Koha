﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Auth.DTO
{
    public class TokenValidationDto
    {
        [Required]
        public string? Token { get; set; }
    }
}
