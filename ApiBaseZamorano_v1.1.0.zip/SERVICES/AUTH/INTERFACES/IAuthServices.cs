﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Services.Auth.Interfaces
{
    public interface IAuthServices
    {
        Task<ResponseModel> AuthenticationRequestPost(string path, object body);
    }
}
